use cmp;
/*
 Navicat Premium Data Transfer

 Source Server         : mine
 Source Server Type    : MySQL
 Source Server Version : 50717
 Source Host           : localhost:3306
 Source Schema         : free

 Target Server Type    : MySQL
 Target Server Version : 50717
 File Encoding         : 65001

 Date: 14/07/2022 17:32:46
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for log_operate
-- ----------------------------
DROP TABLE IF EXISTS `log_operate`;
CREATE TABLE `log_operate`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增长',
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作类型：新增、修改、删除、登录、登出',
  `resource` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作资源',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '操作内容',
  `ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作人IP地址',
  `run_time` bigint(20) NULL DEFAULT NULL COMMENT '方法执行时间',
  `method` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '执行方法名',
  `result` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '返回结果',
  `operator` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作人',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 170 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '操作日志' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for res_cluster
-- ----------------------------
DROP TABLE IF EXISTS `res_cluster`;
CREATE TABLE `res_cluster`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `uuid` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '唯一标志',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `cpf_id` int(11) NOT NULL COMMENT '云平台id',
  `datacenter` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '数据中心',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '集群属于数据中心下级' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for res_data_center
-- ----------------------------
DROP TABLE IF EXISTS `res_data_center`;
CREATE TABLE `res_data_center`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `uuid` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '唯一标志',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `cpf_id` int(11) NOT NULL COMMENT '云平台id',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '数据中心：对应的公有云平台是地域，数据中心属于平台资源顶级分类' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for res_data_store
-- ----------------------------
DROP TABLE IF EXISTS `res_data_store`;
CREATE TABLE `res_data_store`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `uuid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '唯一标志',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `cpf_id` int(11) NOT NULL COMMENT '云平台id',
  `datacenter` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '数据中心',
  `capacity` bigint(20) NOT NULL DEFAULT 0 COMMENT '空间总量（单位byte）',
  `free_space` bigint(20) NOT NULL DEFAULT 0 COMMENT '可用空间（单位byte）',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `run_state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '状态',
  `ssd_flag` tinyint(10) NULL DEFAULT NULL COMMENT '是否为SSD',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '存储' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for res_host_machine
-- ----------------------------
DROP TABLE IF EXISTS `res_host_machine`;
CREATE TABLE `res_host_machine`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `ip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '宿主机ip',
  `uuid` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '唯一标志',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `cpf_id` int(11) NOT NULL COMMENT '云平台id',
  `datacenter` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '数据中心',
  `cluster` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '集群',
  `cpu` bigint(11) NULL DEFAULT 0 COMMENT 'cpu（单位Hz）1GHz=1000MHz',
  `memory` bigint(11) NULL DEFAULT 0 COMMENT '内存（单位byte）',
  `store` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '存储多个存储用逗号分隔',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `os_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作系统名称',
  `cpu_model` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'CPU型号',
  `network_card_number` int(11) NULL DEFAULT NULL COMMENT '网卡数量',
  `conn_state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '连接状态',
  `run_state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '运行状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '宿主机' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for res_ip
-- ----------------------------
DROP TABLE IF EXISTS `res_ip`;
CREATE TABLE `res_ip`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `ip` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'IP地址',
  `subnet_id` int(11) NOT NULL DEFAULT 0 COMMENT '所属子网',
  `locked` int(11) NOT NULL DEFAULT 0 COMMENT '锁定状态：0-否，1-是',
  `used` int(11) NOT NULL DEFAULT 0 COMMENT '使用状态：0-未使用，1-已使用',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_ip`(`ip`) USING BTREE,
  INDEX `idx_subnet`(`subnet_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 297 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '子网或私有网络网段对应的IP地址' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for res_network_label
-- ----------------------------
DROP TABLE IF EXISTS `res_network_label`;
CREATE TABLE `res_network_label`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '标签',
  `uuid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '唯一标志',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `cpf_id` int(11) NOT NULL COMMENT '云平台id',
  `datacenter` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '数据中心',
  `switch_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '交换机类型',
  `switch_uuid` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '交换机uuid',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `state` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '状态',
  `host_count` int(11) NULL DEFAULT NULL COMMENT '关联宿主机数量',
  `vm_count` int(11) NULL DEFAULT NULL COMMENT '关联虚拟机数量',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '网络标签' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for res_platform
-- ----------------------------
DROP TABLE IF EXISTS `res_platform`;
CREATE TABLE `res_platform`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '云平台名称',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `ip` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '云平台ip',
  `username` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '密码',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '云平台' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for res_subnet
-- ----------------------------
DROP TABLE IF EXISTS `res_subnet`;
CREATE TABLE `res_subnet`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `uuid` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '唯一标志',
  `cpf_id` int(11) NOT NULL COMMENT '云平台id',
  `datacenter` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '数据中心',
  `network_label` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'vc里的网络标签',
  `ip_pool` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'ip池',
  `mask` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '掩码',
  `gateway` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '网关',
  `dns1` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'DNS1',
  `dns2` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'DNS2',
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '状态：默认0-启动 1-禁用',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '私有网络' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for res_template
-- ----------------------------
DROP TABLE IF EXISTS `res_template`;
CREATE TABLE `res_template`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '模板名称',
  `uuid` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '模板的uuid',
  `size` bigint(20) NOT NULL DEFAULT 0 COMMENT '模板磁盘大小单位kb',
  `cpf_id` int(11) NOT NULL COMMENT '云平台id',
  `cpf_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '云平台类型',
  `datacenter` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '数据中心',
  `host_machine` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '宿主机',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '状态',
  `datastore` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '关联存储',
  `provision_space` bigint(20) NULL DEFAULT NULL COMMENT '置备空间 GB',
  `used_space` bigint(20) NULL DEFAULT NULL COMMENT '已用空间 GB',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '镜像模板' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for res_virtual_machine
-- ----------------------------
DROP TABLE IF EXISTS `res_virtual_machine`;
CREATE TABLE `res_virtual_machine`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `uuid` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '云主机uuid',
  `cpu` int(11) NOT NULL DEFAULT 0 COMMENT 'cpu-单位核',
  `memory` int(11) NOT NULL DEFAULT 0 COMMENT '内存-单位MB',
  `ipv4` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'ipv4地址，多个用逗号分隔',
  `cpf_id` int(11) NOT NULL COMMENT '云平台ID',
  `cpf_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '云平台类型',
  `datacenter` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '数据中心',
  `host_machine` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '宿主机',
  `instance_status` int(11) NULL DEFAULT NULL COMMENT '状态：0-未知 1-开机 2-关机 3-挂起 10-创建中',
  `os_name` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '操作系统名称',
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '密码',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_uuid`(`uuid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 248 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '云主机' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_permission
-- ----------------------------
DROP TABLE IF EXISTS `sys_permission`;
CREATE TABLE `sys_permission`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增长',
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '权限名称',
  `parent_id` int(11) NOT NULL DEFAULT 0 COMMENT '父菜单',
  `url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '权限地址',
  `code` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '权限标识',
  `type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'menu' COMMENT '权限类型：menu、button',
  `icon` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '图标',
  `sort` int(11) NOT NULL DEFAULT 0 COMMENT '菜单排序号',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 44 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '权限表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_permission
-- ----------------------------
INSERT INTO `sys_permission` VALUES (1, 'dashboard', 0, 'dashboard/Index', 'dashboard', 'menu', 'dashboard', 0, '2022-05-03 09:04:45', '仪表盘');
INSERT INTO `sys_permission` VALUES (2, 'console', 0, 'RouteView', 'resource:console', 'menu', 'laptop', 0, '2022-05-03 09:03:58', '控制台');
INSERT INTO `sys_permission` VALUES (3, 'vm', 2, 'console/Index', 'resource:vm:query', 'menu', 'desktop', 0, '2022-05-03 14:48:56', '云实例');
INSERT INTO `sys_permission` VALUES (4, 'framework', 0, 'RouteView', 'resource:framework', 'menu', 'apartment', 0, '2022-05-03 14:52:23', '基础架构');
INSERT INTO `sys_permission` VALUES (5, 'platform', 4, 'framework/platform/Index', 'resource:platform:query', 'menu', 'cloud', 0, '2022-05-03 14:53:17', '云平台');
INSERT INTO `sys_permission` VALUES (6, 'cluster', 4, 'framework/cluster/Index', 'resource:cluster:query', 'menu', 'cluster', 0, '2022-05-03 14:53:52', '集群');
INSERT INTO `sys_permission` VALUES (7, 'host', 4, 'framework/host/Index', 'resource:host:query', 'menu', 'cloud-server', 0, '2022-05-03 17:36:33', '计算节点');
INSERT INTO `sys_permission` VALUES (8, 'datastore', 4, 'framework/datastore/Index', 'resource:datastore:query', 'menu', 'database', 0, '2022-05-03 14:55:36', '存储');
INSERT INTO `sys_permission` VALUES (9, 'network', 0, 'RouteView', 'resource:network', 'menu', 'global', 0, '2022-05-03 14:56:15', '网络');
INSERT INTO `sys_permission` VALUES (10, 'subnet', 9, 'network/Index', 'resource:subnet:query', 'menu', 'gold', 0, '2022-05-03 14:56:48', '子网');
INSERT INTO `sys_permission` VALUES (11, 'monitor', 0, 'RouteView', 'monitor:resource', 'menu', 'alert', 0, '2022-05-03 16:38:19', '监控');
INSERT INTO `sys_permission` VALUES (12, 'monitorvm', 11, 'monitor/vm/Index', 'monitor:vm:query', 'menu', 'code', 0, '2022-05-03 14:58:42', '云实例');
INSERT INTO `sys_permission` VALUES (13, 'monitorhost', 11, 'monitor/host/Index', 'monitor:host:query', 'menu', 'cloud-server', 0, '2022-05-03 14:59:19', '计算节点');
INSERT INTO `sys_permission` VALUES (14, 'log', 0, 'RouteView', 'log:action', 'menu', 'file', 0, '2022-05-03 15:00:27', '日志');
INSERT INTO `sys_permission` VALUES (15, 'action', 14, 'log/Index', 'log:action:query', 'menu', 'message', 0, '2022-05-03 15:00:59', '操作记录');
INSERT INTO `sys_permission` VALUES (16, 'setting', 0, 'RouteView', 'sys:setting', 'menu', 'setting', 0, '2022-05-03 15:01:34', '设置');
INSERT INTO `sys_permission` VALUES (17, 'user', 16, 'account/user/Index', 'sys:user:query', 'menu', 'user', 0, '2022-05-03 15:02:09', '用户管理');
INSERT INTO `sys_permission` VALUES (18, 'role', 16, 'account/role/Index', 'sys:role:query', 'menu', 'team', 0, '2022-05-04 17:10:30', '角色管理');
INSERT INTO `sys_permission` VALUES (20, 'userAdd', 17, 'userAdd', 'sys:user:add', 'button', 'user', 0, '2022-05-03 16:56:44', '新增用户');
INSERT INTO `sys_permission` VALUES (21, 'userUpdate', 17, 'userUpdate', 'sys:user:update', 'button', 'user', 0, '2022-05-03 16:57:49', '修改用户');
INSERT INTO `sys_permission` VALUES (22, 'userDelete', 17, 'userDelete', 'sys:user:delete', 'button', 'user', 0, '2022-05-03 18:03:46', '删除用户');
INSERT INTO `sys_permission` VALUES (23, 'roleAdd', 18, 'roleAdd', 'sys:role:add', 'button', 'team', 0, '2022-05-03 18:40:23', '新增角色');
INSERT INTO `sys_permission` VALUES (24, 'roleUpdate', 18, 'roleUpdate', 'sys:role:update', 'button', 'team', 0, '2022-05-03 18:42:00', '修改角色');
INSERT INTO `sys_permission` VALUES (25, 'roleDelete', 18, 'roleDelete', 'sys:role:delete', 'button', 'team', 0, '2022-05-03 18:42:43', '删除角色');
INSERT INTO `sys_permission` VALUES (26, 'roleAuthorization', 18, 'roleAuthorization', 'sys:role:auth', 'button', 'team', 0, '2022-05-03 18:43:53', '角色授权');
INSERT INTO `sys_permission` VALUES (27, 'plateformAdd', 5, 'plateformAdd', 'resource:platform:add', 'button', 'cloud', 0, '2022-05-05 10:59:50', '新增平台');
INSERT INTO `sys_permission` VALUES (28, 'plateformUpdate', 5, 'plateformUpdate', 'resource:platform:update', 'button', 'cloud', 0, '2022-05-05 11:00:56', '修改平台');
INSERT INTO `sys_permission` VALUES (29, 'plateformDelete', 5, 'plateformDelete', 'resource:platform:delete', 'button', 'cloud', 0, '2022-05-05 11:01:47', '删除平台');
INSERT INTO `sys_permission` VALUES (30, 'subnetAdd', 10, 'subnetAdd', 'resource:subnet:add', 'button', 'gold', 0, '2022-05-06 13:20:58', '新增子网');
INSERT INTO `sys_permission` VALUES (31, 'subnetUpdate', 10, 'subnetUpdate', 'resource:subnet:update', 'button', 'gold', 0, '2022-05-06 13:21:14', '修改子网');
INSERT INTO `sys_permission` VALUES (32, 'subnetDelete', 10, 'subnetDelete', 'resource:subnet:delete', 'button', 'gold', 0, '2022-05-06 13:21:25', '删除子网');
INSERT INTO `sys_permission` VALUES (33, 'vmPowerOn', 3, 'vmPowerOn', 'resource:vm:powerOn', 'button', 'desktop', 0, '2022-05-09 17:50:18', '开机');
INSERT INTO `sys_permission` VALUES (34, 'vmPowerOff', 3, 'vmPowerOff', 'resource:vm:powerOff', 'button', 'desktop', 0, '2022-05-09 17:50:26', '强制关机');
INSERT INTO `sys_permission` VALUES (35, 'vmReboot', 3, 'vmReboot', 'resource:vm:reboot', 'button', 'desktop', 0, '2022-05-09 17:50:31', '重启');
INSERT INTO `sys_permission` VALUES (36, 'vmShutdown', 3, 'vmShutdown', 'resource:vm:shutdown', 'button', 'desktop', 0, '2022-05-09 17:50:37', '关机');
INSERT INTO `sys_permission` VALUES (37, 'vmSuspend', 3, 'vmSuspend', 'resource:vm:suspend', 'button', 'desktop', 0, '2022-05-09 17:50:42', '挂起');
INSERT INTO `sys_permission` VALUES (38, 'vmDestroy', 3, 'vmDestroy', 'resource:vm:destroy', 'button', 'desktop', 0, '2022-05-09 17:51:33', '销毁');
INSERT INTO `sys_permission` VALUES (39, 'plateformSync', 5, 'plateformSync', 'resource:platform:sync', 'button', 'cloud', 0, '2022-05-09 21:46:32', '同步平台');
INSERT INTO `sys_permission` VALUES (40, 'vmCreate', 3, 'vmCreate', 'resource:vm:create', 'button', 'desktop', 0, '2022-05-17 20:03:49', '创建');
INSERT INTO `sys_permission` VALUES (41, 'vmVnc', 3, 'vmVnc', 'resource:vm:getVncTokenOrUrl', 'button', 'desktop', 0, '2022-06-29 14:02:57', '获取VNC信息');
INSERT INTO `sys_permission` VALUES (42, 'clearVcAlarm', 5, 'clearVcAlarm', 'resource:platform:clearVcAlarm', 'button', 'desktop', 0, '2022-07-07 10:42:49', '清除vc告警');
INSERT INTO `sys_permission` VALUES (43, 'acknowledgeVcAlarm', 5, 'acknowledgeVcAlarm', 'resource:platform:acknowledgeVcAlarm', 'button', 'desktop', 0, '2022-07-07 10:43:15', '确认vc告警');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增长',
  `name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色名',
  `parent_id` int(11) NOT NULL DEFAULT 0 COMMENT '父级角色',
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '描述',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '管理员', 0, '管理员系统权限最大的用户', '2022-05-04 14:48:21');

-- ----------------------------
-- Table structure for sys_role_permission_relation
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_permission_relation`;
CREATE TABLE `sys_role_permission_relation`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增长',
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  `permission_id` int(11) NOT NULL COMMENT '权限ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 70 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '角色和权限关系表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_permission_relation
-- ----------------------------
INSERT INTO `sys_role_permission_relation` VALUES (1, 1, 1);
INSERT INTO `sys_role_permission_relation` VALUES (2, 1, 2);
INSERT INTO `sys_role_permission_relation` VALUES (3, 1, 3);
INSERT INTO `sys_role_permission_relation` VALUES (4, 1, 4);
INSERT INTO `sys_role_permission_relation` VALUES (5, 1, 5);
INSERT INTO `sys_role_permission_relation` VALUES (6, 1, 6);
INSERT INTO `sys_role_permission_relation` VALUES (7, 1, 7);
INSERT INTO `sys_role_permission_relation` VALUES (8, 1, 8);
INSERT INTO `sys_role_permission_relation` VALUES (9, 1, 9);
INSERT INTO `sys_role_permission_relation` VALUES (10, 1, 10);
INSERT INTO `sys_role_permission_relation` VALUES (11, 1, 11);
INSERT INTO `sys_role_permission_relation` VALUES (12, 1, 12);
INSERT INTO `sys_role_permission_relation` VALUES (13, 1, 13);
INSERT INTO `sys_role_permission_relation` VALUES (14, 1, 14);
INSERT INTO `sys_role_permission_relation` VALUES (15, 1, 15);
INSERT INTO `sys_role_permission_relation` VALUES (16, 1, 16);
INSERT INTO `sys_role_permission_relation` VALUES (17, 1, 17);
INSERT INTO `sys_role_permission_relation` VALUES (27, 1, 24);
INSERT INTO `sys_role_permission_relation` VALUES (28, 1, 18);
INSERT INTO `sys_role_permission_relation` VALUES (34, 1, 26);
INSERT INTO `sys_role_permission_relation` VALUES (37, 1, 20);
INSERT INTO `sys_role_permission_relation` VALUES (38, 1, 21);
INSERT INTO `sys_role_permission_relation` VALUES (39, 1, 22);
INSERT INTO `sys_role_permission_relation` VALUES (40, 1, 23);
INSERT INTO `sys_role_permission_relation` VALUES (41, 1, 25);
INSERT INTO `sys_role_permission_relation` VALUES (46, 1, 27);
INSERT INTO `sys_role_permission_relation` VALUES (47, 1, 28);
INSERT INTO `sys_role_permission_relation` VALUES (48, 1, 29);
INSERT INTO `sys_role_permission_relation` VALUES (49, 1, 30);
INSERT INTO `sys_role_permission_relation` VALUES (50, 1, 31);
INSERT INTO `sys_role_permission_relation` VALUES (51, 1, 32);
INSERT INTO `sys_role_permission_relation` VALUES (52, 1, 33);
INSERT INTO `sys_role_permission_relation` VALUES (53, 1, 34);
INSERT INTO `sys_role_permission_relation` VALUES (54, 1, 35);
INSERT INTO `sys_role_permission_relation` VALUES (55, 1, 36);
INSERT INTO `sys_role_permission_relation` VALUES (56, 1, 37);
INSERT INTO `sys_role_permission_relation` VALUES (57, 1, 38);
INSERT INTO `sys_role_permission_relation` VALUES (58, 1, 39);
INSERT INTO `sys_role_permission_relation` VALUES (59, 1, 40);
INSERT INTO `sys_role_permission_relation` VALUES (67, 1, 41);
INSERT INTO `sys_role_permission_relation` VALUES (68, 1, 42);
INSERT INTO `sys_role_permission_relation` VALUES (69, 1, 43);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增长',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '姓名',
  `sex` int(11) NOT NULL DEFAULT 0 COMMENT '性别 0-未知 1-男 2-女',
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '密码',
  `email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '邮箱',
  `phone` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '手机',
  `type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'local' COMMENT 'local-本地用户\r\n            ldap-ldap用户',
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '账号状态0-正常1-锁定',
  `last_login_ip` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '最后登录ip',
  `last_login_time` datetime(0) NULL DEFAULT NULL COMMENT '最后登录时间',
  `create_time` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `deleted` int(11) NOT NULL DEFAULT 0 COMMENT '删除标识位0-正常1-删除',
  `description` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '描述',
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  `role_name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色名称',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '用户表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, '超级管理员', 0, 'admin', '$2a$10$vAYF6JSImqpkYOLi6sGIwerVTQUrA5ELecx/XMutN2wVuwFMEIfla', 'info@tuocloud.cn', '1', 'local', 0, NULL, NULL, '2022-07-14 17:26:39', 0, NULL, 1, '管理员');

SET FOREIGN_KEY_CHECKS = 1;
